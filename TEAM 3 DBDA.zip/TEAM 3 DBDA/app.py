import numpy as np
import pickle
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt


#loading the saved model
loaded_model = pickle.load(open(r'C:\Users\Simran\Desktop\TEAM 3 DBDA\trained_model.sav','rb')) #called to de-serialize a data stream.

#creatng a function for prediction
def aqi_prediction(input_data):
    
    prediction = loaded_model.predict([input_data])
    print(prediction)
    if prediction <=50:
        return "Good"
    elif prediction <=100:
        return 'Satisfactory'
    elif prediction <=200:
        return 'Moderate'
    elif prediction <=300:
        return 'Poor'
    elif prediction <=400:
        return 'Very Poor'
    elif prediction >400:
        return 'Severe'

st.title("Air Quality Index") # Display text in title formatting.

CO =  st.number_input('Value of CO',0) #Display a numeric input widget.
NH3 =  st.number_input('Value of NH3',0)
NO2 =  st.number_input('Value of NO2',0)
OZONE=  st.number_input('Value of OZONE',0)
PM10 =  st.number_input('Value of PM10',0)
PM25 =  st.number_input('Value of PM2.5',0)
SO2 =  st.number_input('Value of SO2',0)

input_data = [CO,NH3,NO2,OZONE,PM10,PM25,SO2]
    
st.write(aqi_prediction(input_data)) #used to display information into your app
prediction = loaded_model.predict([input_data])
st.write(prediction)


st.subheader('Pollutants of your City')
df=pd.DataFrame(data=input_data,columns=['Value'])
df['Pollutants']=['CO','NH3','NO2','OZONE','PM10','PM25','SO2']
fig=plt.figure(figsize=(12,6))
plt.bar(df.Pollutants,df.Value,data=df)
st.pyplot(fig)


